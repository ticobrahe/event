@extends('template.event.layout2')

@section('content')

 <section class="contact-us-area">
  <div class="auto-container">
    <div class="row clearfix">
        <div class="col-md-12 col-md-offset-0 col-sm-6 col-xs-12 contact-form">
            <div style="font-size: 18px"><br>
              <center><h1><strong style="color: green"> Event Security</strong></h1></center>
              <br>
              <div class="container">
                <div class="jumbotron">
                   <p>
                <span style="color: #823C09"><strong>Throwing a party?</strong></span> Organizing or hosting an event? Planning on catering food & serving drinks (Alcohol/Non-Alcohol), hiring a DJ and renting some tables? Depending on the size of your part/event, you might want to add security to that list.<br>
                Having a security presence at your party will not only help to make your event a prestigious one but also help maintain a safe environment for you and your guests as well as protect your property.<br><br>
                <div style="color: green"><h4><strong>Prices for hiring a security guard for a private/corporate event can vary. Some details that factor into the cost includes:</strong></h4></div>
              </p>
              <p>
                <strong>Quality of guards:</strong> Experience, Background and even Costume all factor into the pricing of a guard. If you want an off duty police officer or a guard with a military background, it’s going to cost a little more. If you are looking to keep the price to a minimum, consider that the security Company sending the guard will probably be paying the guard minimum wage. The guard that you should want for your event should have fair amount of experience, present themselves in a professional manner and have effective communication skills in the case of a disturbance.
              </p>
              <p>
                <strong>INDEPENDENT GUARD VS SECURITY COMPANY:</strong>  Many independent guards might cost less; however many times they don’t have liability insurance and sometimes don’t even have a license to perform security guard services. If the guard or one of your guests is hurt, or there is an incident during your party, you run the risk of having a law suit on your hands. Your best bet is to hire a security guard through a licensed and insured company.
              </p>
              <p>
              <strong>
                ARMED VS UNARMED GUARDS:</strong>  Unless your party is being thrown in a dicey area of town or you are going to have high profile guests, you probably won’t need an armed guard. Armed guards add to your cost due to the high risk of liability.
              </p>
              <br>
              <p>
                <div style="color: green"><h4><strong>PARTY TIPS. Suggestions for you to consider when hosting a party </strong></h4></div><br>
                <strong>THE VENUE</strong><br>
                <ul class="category" >
                  <li>-Think about party size </li>
                  <li>-Consider appropriate lighting</li>
                  <li>-Have sufficient restroom</li>
                  <li>-Remember a first aid kit </li>
                  <li>-Allocate proper parking </li>
                  <li>-Designate a room for valuables </li>
                </ul> 
              </p><br>
              
                <div style="color: green"><h4><strong>Guard prices for a party. To give you an idea of how much hiring a security guard will cost based on the factors above, here are some estimated numbers.</strong></h4></div><br>
                <p>
                  <strong>Unlicensed and uninsured independent security guards:</strong><br>
                  Unarmed security guard (High risk, not recommended) - (N10,000/day = 24 hours)
                </p>
                <p>
                  <strong>Security guards provided by licensed & insured security company:</strong><br>
                  <ul class="category">
                    <li>Cobra team (basic) (unarmed) – N10,000 /12 hours(each)</li>
                    <li>First Aid team (for sick, drunk & injured people) - N10,000/ 12 hours(each)<br> (minimum of five operatives) </li><br>
                    <li>Bravo team – (unarmed) – N20,000 /12 hours(each)</li>
                    <li>First Aid team (for sick, drunk & injured people) - N10,000/ 12 hours(each)<br>   (minimum of five operatives) </li><br>
                    <li>Alpha team (unarmed) – N30,000 /12 hours(each) ></li>
                    <li>First Aid team (for sick, drunk & injured people) - N10,000/ 12 hours(each)<br>   (minimum of five operatives).</li><br>
                    <li>Eagle team – N40,000 /12 hours(each) </li>
                    <li>First Aid team (for sick, drunk & injured people) - N10,000/                     12 hours(each)<br>(minimum of five operatives) 
                    </li ><br>
                    <li>Vulture team – N50,000 /12 hours(each) </li>
                    <li>First Aid team (for sick, drunk & injured people) - N10,000/
                     12 hours(each)<br>(minimum of five operatives) 
                    </li ><br>
                    <li>Advance team – N70,000 /12 hours(each) </li>
                    <li>First Aid team (for sick, drunk & injured people) - N10,000/
                     12 hours(each)<br>(minimum of five operatives) 
                    </li >
                  </ul>
                </p><br>
                <p>
                  <strong>NB:</strong> It is mandatory that a First Aid team member be attached to a security team for any event
                </p>
                <p>
                  <strong>Now that you have determined want kind of guards you need,</strong> It’s time to <a  href="/eventsecurity-form">Book Now</a><br>
                  Make sure you plan ahead to save the most. However, if you are in a bind, and need a guard last minute, give Arenaluxuries.com a call now on +234 87562023, +234 8118226135 or send us an email: admin@arenaluxuries.com. We can send out a guard on the spot. 
                </p>
                </div>
              </div>
            </div>
        </div>   
    </div>
  </div>    
</section>

@endsection