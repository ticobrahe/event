@extends('template.event.layout2')

@section('content')
<section class="page-banner" style="background-image:url(images/background/page-banner-bg-2.jpg); margin-top: 100px;">
<div class="auto-container text-center">
  <h1>Arenaluxuries </h1>
  <ul class="bread-crumb"><li><a href="/">Home</a></li> <li>gallery</li></ul>
</div>
 </section>
 <section class="our-projects style-two">
        <div class="auto-container">
            
            <div class="sec-title wow fadeInLeft" data-wow-delay="300ms" data-wow-duration="1000ms">
                <h2>Our <span>Gallery</span></h2>
            </div>
            
            <!--Filters Nav-->
            <ul class="filter-tabs clearfix anim-3-all">
                <!-- <li class="filter" data-role="button" data-filter="buildings"><span class="btn-txt">Buildings</span></li>
                <li class="filter" data-role="button" data-filter="hospital"><span class="btn-txt">Hospital</span></li>
                <li class="filter" data-role="button" data-filter="school"><span class="btn-txt">school</span></li>
                <li class="filter" data-role="button" data-filter="isolation"><span class="btn-txt">Isolation</span></li>
                <li class="filter" data-role="button" data-filter="mall"><span class="btn-txt">Mall</span></li>
                <li class="filter" data-role="button" data-filter="others"><span class="btn-txt">Others</span></li> -->
            </ul>
        </div>
        
        <!--Projects Container-->
       <div class="projects-container filter-list clearfix wow fadeInUp" data-wow-delay="300ms" data-wow-duration="1000ms">
            
            <article class="project-box mix mix_all">
                <figure class="image"><img src="event/images/resource/gallery-1.jpg" alt="" ><a href="event/images/resource/gallery-1.jpg" class="lightbox-image zoom-icon"></a></figure>
                <div class="text-content hvr-bounce-to-bottom">
                    <div class="text">
                        <span class="cat">Arenaluxuries</span>
                    </div>
                </div>
            </article>
            
            <article class="project-box mix mix_all school other buildings">
                <figure class="image"><img src="event/images/resource/gallery-2.jpg" alt=""><a href="event/images/resource/gallery-2.jpg" class="lightbox-image zoom-icon"></a></figure>
                <div class="text-content hvr-bounce-to-bottom">
                    <div class="text">
                        <span class="cat">Arenaluxuries</span>
                    </div>
                </div>
            </article>
            
            <article class="project-box mix mix_all isolation architecture">
                <figure class="image"><img src="event/images/resource/gallery-3.jpg" alt=""><a href="event/images/resource/gallery-3.jpg" class="lightbox-image zoom-icon"></a></figure>
                <div class="text-content hvr-bounce-to-bottom">
                    <div class="text">
                        <span class="cat">Arenaluxuries</span>
                    </div>
                </div>
            </article>
            
            <article class="project-box mix mix_all buildings hospital others">
                <figure class="image"><img src="event/images/resource/proj-image-4.jpg" alt=""><a href="event/images/resource/proj-image-4.jpg" class="lightbox-image zoom-icon"></a></figure>
                <div class="text-content hvr-bounce-to-bottom">
                    <div class="text">
                        <span class="cat">Arenaluxuries</span>
                    </div>
                </div>
            </article>
            
            <article class="project-box mix mix_all buildings architecture">
                <figure class="image"><img src="event/images/resource/gallery-5.jpg" alt=""><a href="event/images/resource/gallery-5.jpg" class="lightbox-image zoom-icon"></a></figure>
                <div class="text-content hvr-bounce-to-bottom">
                    <div class="text">
                        <span class="cat">Arenaluxuries</span>
                    </div>
                </div>
            </article>
            
            <article class="project-box mix mix_all school mall isolation buildings">
                <figure class="image"><img src="event/images/resource/gallery-6.jpg" alt=""><a href="event/images/resource/gallery-6.jpg" class="lightbox-image zoom-icon"></a></figure>
                <div class="text-content hvr-bounce-to-bottom">
                    <div class="text">
                        <span class="cat">Arenaluxuries</span>
                    </div>
                </div>
            </article>
            
            <article class="project-box mix mix_all mall architecture others">
                <figure class="image"><img src="event/images/resource/gallery-7.jpg" alt=""><a href="event/images/resource/gallery-7.jpg" class="lightbox-image zoom-icon"></a></figure>
                <div class="text-content hvr-bounce-to-bottom">
                    <div class="text">
                        <span class="cat">Arenaluxuries</span>
                    </div>
                </div>
            </article>
            
            <article class="project-box mix mix_all mall isolation hospital buildings architecture others">
                <figure class="image"><img src="event/images/resource/gallery-8.jpg" alt=""><a href="event/images/resource/gallery-8.jpg" class="lightbox-image zoom-icon"></a></figure>
                <div class="text-content hvr-bounce-to-bottom">
                    <div class="text">
                        <span class="cat">Arenaluxuries</span>
                    </div>
                </div>
            </article> 
                 
        </div>
        <br><br>
    </section>
@endsection