<header class="main-header style-two">
        <!-- Header Top -->
       <!-- <div class="header-top">
            <div class="auto-container clearfix">     
            </div>
        </div>-->
        <!-- Header Lower -->
  <div class="header-lower">
    <div class="auto-container clearfix">
        <!--Logo-->
        <div class="logo"><a href=""><img src="event/images/logo-2.png" alt="Bulldozer" title="Bulldozer"></a></div>
        <!--Right Container-->
        <div class="right-cont clearfix">
            <nav class="main-menu">
                <div class="navbar-header">
                    <!-- Toggle Button -->      
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                </div> 
                <div class="navbar-collapse clearfix">                                                                                      
                    <ul class="nav navbar-nav navbar-right">
                        <li ><a href="/"><span class="header-color">Home</span></a>
                        </li>
                        <li><a href="/"><span class="header-color">About Us</span></a></li>
                        <li><a href="/"><span class="header-color">Services</span></a>
                        </li>
                        <li><a href="/"><span class="header-color">Gallery</span></a>
                            
                        </li>
                        <li><a href="/"><span class="header-color" >Team</span></a></li>
                        <li><a ><span class="header-color">Book Now</span></a>
                            <ul class="submenu">
                                <li><a href="/events">Events</a></li>
                                <li><a href="/eventsecurity">Event Security</a></li>
                                <li><a href="/privatesecurity">Private Security</a></li>
                                <li><a href="/corporatesecurity">Corperate Security</a></li>
                                <li><a href="/generalconsultancy">General Consultancy</a></li>
                            </ul>
                        </li>
                        <li><a href="/career"><span class="header-color>Careers</span></a></li>
                        <li><a href="/"><span class="header-color">Contact Us</span></a></li>
                    </ul>
                    <div class="clearfix"></div>
                </div>
            </nav>
        </div> 
    </div> 
  </div>
</header>