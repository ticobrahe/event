<!DOCTYPE html>
<html>

<head>
<meta charset="utf-8">
<title>Arenalluries</title>

<link href="event/css/bootstrap.css" rel="stylesheet">
<link href="event/css/revolution-slider.css" rel="stylesheet">
<link href="event/css/owl.css" rel="stylesheet">
{{Html::style('event/css/style.css')}}
{{Html::style('event/css/style.css')}}

<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<link href="event/css/responsive.css" rel="stylesheet">
</head>
<style type="text/css">
	.bgcolour{
		background-color: blue;
	}
</style>

<body >
<div class="page-wrapper">
    <div class="preloader"></div>
    @include('template.event.header')
    @yield('content')
    @include('template.event.footer')
</div>

<script src="event/js/jquery.js"></script> 
<script src="event/js/bootstrap.min.js"></script>
<script src="event/js/revolution.min.js"></script>
<script src="event/js/bxslider.js"></script>
<script src="event/js/owl.carousel.min.js"></script>
<script src="event/js/jquery.mixitup.min.js"></script>
<script src="event/js/jquery.fancybox.pack.js"></script>
<script src="event/js/wow.js"></script>
<script src="event/js/script.js"></script>

</body>
</html>